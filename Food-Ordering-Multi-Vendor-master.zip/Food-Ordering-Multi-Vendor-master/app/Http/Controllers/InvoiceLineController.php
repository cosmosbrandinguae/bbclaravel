<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvoiceLineController extends Controller
{
    //
}
